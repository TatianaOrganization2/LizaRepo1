#!/bin/sh
"$@"

while true; do
  sleep 10
done
